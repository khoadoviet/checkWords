package a1_2001140032;

public class Match implements Comparable<Match> {
    private int freq;
    private int firstIndex;
    private Word word;
    private Doc doc;
    public Match(Doc d, Word w, int freq, int firstIndex) {
            this.freq=freq;
            this.firstIndex=firstIndex;
            word = w;
            this.doc = d;
    }
    public int getFreq() {
        return freq;
    }
    public int getFirstIndex() {
        return firstIndex;
    }
    public int compareTo(Match o) {
        if (this.getFirstIndex() == o.getFirstIndex()) return 0;
        else if (this.getFirstIndex() > o.getFirstIndex()) return 1;
        else return -1;
    }

    public Word getWord() {
        return word;
    }
}
