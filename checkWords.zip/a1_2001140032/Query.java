package a1_2001140032;

import java.util.*;

public class Query {
    private List<String> cp;
    private List<Word> listKey;
    public Query(String searchPhrase) {
        cp = new ArrayList<>();
        String[] s = searchPhrase.split(" ");
        cp.addAll(Arrays.asList(s));
    }
    public List<Word> getKeywords() {
        listKey = new ArrayList<>();

        for (String s : cp) {
            Word w = Word.createWord(s);
            if (w.isKeyword()) listKey.add(w);
        }

        return listKey;
    }
    public List<Match> matchAgainst(Doc d) {
        List<Match> matches = new ArrayList<>();
        List<Word> doc = new ArrayList<>();
        doc.addAll(d.getTitle());
        doc.addAll(d.getBody());
        List<Word> appearWord = new ArrayList<>();
        for (Word keyWord : this.getKeywords()) {
            if (doc.contains(keyWord)) {
                appearWord.add(keyWord);
            }

        }
        for (Word keyW : appearWord) {
            int freq = Collections.frequency(doc,keyW);
            int firstIndex = doc.indexOf(keyW);
            if (freq > 0) {
                Match m = new Match(d,keyW,freq,firstIndex);
                matches.add(m);
            }
        }
        return sortedByFreq(matches);
    }

    public List<Match> sortedByFreq(List<Match> matches) {
        matches.sort(new Comparator<Match>() {
            @Override
            public int compare(Match o1, Match o2) {
                if (o1.getFirstIndex() > o2.getFirstIndex()) return 1;
                else if (o1.getFirstIndex() < o2.getFirstIndex()) return -1;
                else return 0;


            }
        });
        return matches;
    }

}
