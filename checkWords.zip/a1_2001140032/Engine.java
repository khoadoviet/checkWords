package a1_2001140032;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Engine {
    private Doc[] doc;
    private int lengthDoc;
    private List<Result> results;
    public int loadDocs(String dirname) {

        lengthDoc = 0;
        File file = new File(dirname);
        File[] ls = file.listFiles();
        assert ls != null;
        lengthDoc = ls.length;
        doc = new Doc[lengthDoc];
        for (int i = 0; i < lengthDoc;i++) {

            StringBuilder content = new StringBuilder();
            try {
                File f = new File(String.valueOf(ls[i]));
                Scanner sc = new Scanner(f);
                while (sc.hasNextLine()) {

                    String line = sc.nextLine();
                    content.append(line).append("\n");
                }
                Doc c = new Doc(content.toString().trim());
                doc[i] = c;
                sc.close();

            } catch (FileNotFoundException e) {

        }

        }
        return lengthDoc;
    }
    public Doc[] getDocs() {
        return doc;
    }
    public List<Result> search(Query q) {
        results = new ArrayList<>();
            for (Doc d: doc) {
                List<Match> matches = q.matchAgainst(d);
                if (matches.size() > 0) {
                    Result result = new Result(d,matches);
                    results.add(result);
                }
            }
        Collections.sort(results);
        return results;
    }

    public String htmlResult(List<Result> results) {
        StringBuilder s = new StringBuilder();
        for (Result result : results) {
            s.append(result.htmlHighlight() );
        }
        return s.toString();
    }
}
