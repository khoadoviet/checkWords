package a1_2001140032;

import java.util.ArrayList;
import java.util.List;

public class Result implements Comparable<Result>{
    private Doc doc;
    private List<Match> matches;
    public Result(Doc d, List<Match> matches) {
        this.doc = d;
        this.matches = matches;
    }
    public List<Match> getMatches(){
        return matches;
    }
    public int getTotalFrequency() {
        int totalFrequency = 0;
        for (Match m : matches) {
            totalFrequency += m.getFreq();
        }
        return totalFrequency;
    }
    public double getAverageFirstIndex() {
        double totalFIndex = 0;
        for (Match m : matches) {
            totalFIndex += m.getFirstIndex();
        }
        return totalFIndex/matches.size();
    }
    public String htmlHighlight() {
        String resultTitle = "";
        String resultBody = "";
        List<Word> textTitle = new ArrayList<>(getDoc().getTitle());
        List<Word> textBody = new ArrayList<>(getDoc().getBody());
        for (Match m : matches) {
            for (Word word : textTitle) {
                if (m.getWord().equals(word)) {
                    int index = textTitle.indexOf(word);
                    String s = word.getPrefix() + "<u>" + word.getText() + "</u>" + word.getSuffix();
                    Word newWord = Word.createWord(s);
                    textTitle.set(index,newWord);
                }
            }
            for (Word word : textBody) {
                if (m.getWord().equals(word)) {
                    int index = textBody.indexOf(word);
                    String s = word.getPrefix() + "<b>" + word.getText() + "</b>" + word.getSuffix();
                    Word newWord = Word.createWord(s);
                    textBody.set(index,newWord);
                }
            }
        }
        String tt = "";
        for (int i = 0; i < textTitle.size();i++) {
            tt += textTitle.get(i).toString() + " ";
        }
        String bb = "";
        for (int i = 0; i < textBody.size();i++) {
            bb += textBody.get(i).toString() + " ";
        }
        resultTitle = "<h3>" + tt.trim() + "</h3>";
        resultBody = "<p>" + bb.trim() + "</p>";

        return resultTitle.trim() + resultBody.trim();
    }
    public int compareTo(Result o) {
        if (this.getMatches().size() < o.getMatches().size()) return 1;
        else if (this.getMatches().size() > o.getMatches().size()) return -1;
        else {
            if (getTotalFrequency() < o.getTotalFrequency()) return 1;
            else if (getTotalFrequency() > o.getTotalFrequency()) return -1;
            else {
                if (getAverageFirstIndex() > o.getAverageFirstIndex()) return 1;
                else if (getAverageFirstIndex() < o.getAverageFirstIndex()) return -1;
                else return 0;
            }
        }
    }
    // newAdd
    public Doc getDoc() {
        return doc;
    }

}
