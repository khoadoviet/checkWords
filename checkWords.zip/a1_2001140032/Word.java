package a1_2001140032;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Word {
    public static Set<String> stopWords;
    private String rawText;


    private Word(String rawText) {
        this.rawText = rawText;
    }

    public static Word createWord(String rawText) {
        Word w = new Word(rawText);
        return w;
    }

    public boolean isKeyword() {
        if (!isValid()) {
            return false;
        }
        return !stopWords.contains(getText().toLowerCase());
    }

    public String getPrefix() {
        String prefix = "";
        int lengthText = this.rawText.length();
        if(isValid()) {
            for (int i = 0; i < lengthText; i++) {
                if (Character.isLetterOrDigit(this.rawText.charAt(i))) {
                    prefix = this.rawText.substring(0, i);
                    break;
                }
            }
        }
        return prefix;
    }

    public String getSuffix() {
        String suffix = "";
        if(isValid()) {
            int pre = getPrefix().length();
            String s = this.rawText.substring(pre);
            for (int i = 0; i < s.length(); i++) {
                if (!Character.isLetterOrDigit(s.charAt(i))) {
                    if (s.charAt(i) != '-') {
                        if (s.charAt(i) == '\'') {
                            if (!s.startsWith("'t", i)) {
                                suffix = s.substring(i);
                                break;
                            }
                        } else {
                            suffix = s.substring(i);
                            break;
                        }
                    }
                }
            }
        }
        return suffix;
    }

    public String getText() {
        String text = this.rawText;
        if (isValid()) {
            int suf = getSuffix().length();
            text = this.rawText.substring(getPrefix().length(), this.rawText.length() - suf);
        }
        return text;
    }

    public static boolean loadStopWords(String fileName) {
        try {
            stopWords = new HashSet<>();
            File f = new File(fileName);
            Scanner sc = new Scanner(f);
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                stopWords.add(line.trim());
            }
            sc.close();
            return true;
        } catch (FileNotFoundException e) {

            return false;
        }
    }

    @Override
    public boolean equals(Object o) {
        Word otherWord = (Word)o;
        return otherWord.getText().equalsIgnoreCase(this.getText());
    }

    @Override
    public String toString() {
        return this.rawText;
    }
    public boolean checkAlphabetic(char x) {
        return Character.isAlphabetic(x);
    }
    public boolean isValid() {
        String validPattern = ".*[,!?.)}\"].*";
        String inValidPattern = ".*[ @#$%^*_+\\[\\]].*";
        int quoteSingle = 0;
        int countWord = 0;
        int sizeOfRawText = this.rawText.length();
        for (int i = 0; i < sizeOfRawText; i++) {
            char x = this.rawText.charAt(i);
            //check number
            if (Character.isDigit(x))
                return false;
            if (checkAlphabetic(x)) {
                countWord++;
                continue;
            }

            // check qoute
            if (x == '\'') {
                quoteSingle++;
                if (quoteSingle > 1) return false;

                if (i - 1 < 0 || !checkAlphabetic(this.rawText.charAt(i - 1))
                        || i + 1 >= sizeOfRawText || !checkAlphabetic(this.rawText.charAt(i + 1))){
                    return false;
                }
                continue;
            }
            // Object-oriented
            if (x == '-') {
                if (i - 1 < 0 || !checkAlphabetic(this.rawText.charAt(i - 1)) || i + 1 >= sizeOfRawText
                        || !checkAlphabetic(
                        this.rawText.charAt(i + 1))) {return false;}
            }

            if (String.valueOf(x).matches(validPattern) && (i == sizeOfRawText - 1)
                    && ((i - 1) > 0) && Character.isLetter(this.rawText.charAt(i - 1))) {
                continue;
            }
            if (String.valueOf(x).matches(".*['\"({\\[<].*") && i == 0) continue;
            if ((String.valueOf(x).matches(".*['({\\[<].*") && (i  == sizeOfRawText - 1)) || ((String.valueOf(x).matches(".*['({\\[<].*") && i -1 > 0 && checkAlphabetic(this.rawText.charAt(i-1))))){
                return false;
            }

            if (String.valueOf(x).matches(validPattern) && i ==0){
                return false;
            }

            if (String.valueOf(x).matches(inValidPattern)){
                return false;
            }
            if((String.valueOf(x).matches(validPattern) || String.valueOf(x).matches(".*['\"({\\[<].*")) && i -1 >0 && checkAlphabetic(this.rawText.charAt(i-1)) && i +1 < sizeOfRawText && checkAlphabetic(this.rawText.charAt(i+1))){
                return false;
            }

        }
        return countWord > 0;
    }

}