package a1_2001140032;

import java.util.ArrayList;
import java.util.List;
public class Doc {
    private String content;
    private String title;
    private String body;
    public Doc(String content) {
        String[] c = content.split("\n");
        this.content = content;
        title = c[0];
        body = c[1];
    }

    public List<Word> getTitle(){
        List<Word> titleList = new ArrayList<>();
        String[] s = title.split(" ");
        for (String value : s) {
            Word w = Word.createWord(value);
            titleList.add(w);
        }

        return titleList;
    }
    public List<Word> getBody() {
        List<Word> titleBody = new ArrayList<>();
        String[] s = body.split(" ");
        for (String value : s) {
            Word w = Word.createWord(value);
            titleBody.add(w);
        }
        return titleBody;
    }
    public boolean equals(Object o) {
        Doc d = (Doc)o;
        if (d.getTitle().size() != this.getTitle().size() || d.getBody().size() != this.getBody().size()) {
            return false;
        }
        for (int i = 0; i < d.getTitle().size();i++) {
            if (!this.getTitle().get(i).equals(d.getTitle().get(i))) {
                return false;
            }
        }
        for (int i = 0; i < d.getBody().size();i++) {
            if (!this.getBody().get(i).equals(d.getBody().get(i))) {
                return false;
            }
        }
        return true;
    }

    //test
    public String toString(){
        return content;
    }
}
